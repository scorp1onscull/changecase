#include <fstream>

void toggle_case(std::ifstream & inFile, std::ofstream & outFile);

void to_lower_case(std::ifstream & inFile, std::ofstream & outFile);

void to_upper_case(std::ifstream & inFile, std::ofstream & outFile);

void to_title_case(std::ifstream & inFile, std::ofstream & outFile);

